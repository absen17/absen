package com.infy.set;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class Student {
    private int rollNumber;
    private String name;

    public Student(int rollNumber, String name) {
        this.rollNumber = rollNumber;
        this.name = name;
    }

    public int getId() {
        return rollNumber;
    }

    public void setId(int rollNumber) {
        this.rollNumber = rollNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student student = (Student) o;
        return rollNumber == student.rollNumber && Objects.equals(name, student.name);
    }

    public int hashCode() {
        return Objects.hash(rollNumber, name);
    }

    public String toString() {
        return "Student{id=" + rollNumber + ", name='" + name + '\'' + '}';
    }
    
        public static void main(String[] args) {
            Student student1 = new Student(100, "AAA");
            Student student2 = new Student(200, "BBB");
            Student student3 = new Student(100, "AAA"); 

            Set<Student> students = new HashSet<>();
            students.add(student1);
            students.add(student2);
            students.add(student3);

            for (Student student : students) {
                System.out.println(student);
            }
       }
}
