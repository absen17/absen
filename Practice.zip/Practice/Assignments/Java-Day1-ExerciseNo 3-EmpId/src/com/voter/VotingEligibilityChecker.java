package com.voter;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class VotingEligibilityChecker {
    public static void main(String[] args) {
        // Create a scanner to get the user's date of birth input
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter your date of birth (dd-MM-yyyy): ");
        String dobInput = scanner.nextLine();

        // Define the date format
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        // Parse the input date of birth
        LocalDate dob = LocalDate.parse(dobInput, formatter);

        // Get the current date
        LocalDate currentDate = LocalDate.now();

        // Calculate the age
        Period age = Period.between(dob, currentDate);

        // Check if the age is 18 or older
        if (age.getYears() >= 18) {
            System.out.println("You are eligible to vote.");
        } else {
            // Calculate the time remaining to turn 18
            LocalDate eligibilityDate = dob.plusYears(18);
            Period timeRemaining = Period.between(currentDate, eligibilityDate);
            System.out.println("You will be eligible to vote in "
                    + timeRemaining.getYears() + " years, "
                    + timeRemaining.getMonths() + " months, and "
                    + timeRemaining.getDays() + " days.");
        }

        // Close the scanner
        scanner.close();
    }
}