/**
 * 
 */
/**
 * 
 */
module Voter {
}