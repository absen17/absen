package com.infy.map;

public class MapAssignment {
	public static void main(String[] args) {
		
	}
}
