package com.infy.list;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class LinkedListAssignment {
	public static void main(String[] args) {
		//defining LinkedList
		LinkedList<String> linkedList = new LinkedList<>();
		
		//adding four names
		linkedList.add("AAM");
		linkedList.add("JAM");
		linkedList.add("KATHAL");
		linkedList.add("KOLA");
		
		// Traversing through for loop
		System.out.println("Traversing through For Loop: ");
		for(int i=0;i<linkedList.size();i++) {
			System.out.println(linkedList.get(i));
		}
		
		//removing first & last names
		linkedList.removeFirst();
		linkedList.removeLast();
		
		// Traversing through advanced for loop
		System.out.println("Traversing through Advanced For Loop: ");
		for(String liString :linkedList) {
			System.out.println(liString);
		}
		
		linkedList.addFirst("Lebu");
		linkedList.addLast("Lanka");
		
		//Printing Using Iterator
		System.out.println("Printing using Iterator: ");
		ListIterator<String> listIterator = linkedList.listIterator();
		while(listIterator.hasNext()) {
			System.out.println(listIterator.next());
		}
		System.out.println();
	}
}
