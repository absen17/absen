package com.infy.list;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class ArrayListAssignment {
	public static void main(String[] args) {
		
		//defining ArrayList() of String
		List<String> arrayList = new ArrayList<>();
		arrayList.add("Bulbul");
		arrayList.add("Pakhi");
		arrayList.add("Moina");
		arrayList.add("Tiya");
		//traversing forward method
		ListIterator<String> forwardList = arrayList.listIterator();
		System.out.println("Printing the List in Forward Direction: ");
		
		while(forwardList.hasNext()) {
			System.out.println(forwardList.next());
		}
		System.out.println();
		
		//traversing backward method
		ListIterator<String> backwardList = arrayList.listIterator(arrayList.size());
		System.out.println("Printing the List in Reverse Direction: ");
		
		while(backwardList.hasPrevious()) {
			System.out.println(backwardList.previous());
		}
		System.out.println();
	}
}
