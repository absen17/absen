package ValidatorPractice;

public class RegistrationDTO {

	public String getvehicleNumber() {
		// TODO Auto-generated method stub
		return null;
	}

}
