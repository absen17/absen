package ValidatorPractice;

public class isValidPaymentType {

	public static boolean getpaymentType() {
		// TODO Auto-generated method stub
		return false;
	}

}
