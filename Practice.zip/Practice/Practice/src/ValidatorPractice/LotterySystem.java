package ValidatorPractice;

import ValidatorPracticeDTO.LotteryBookingException;
import ValidatorPracticeDTO.ParticipantDTO;

public class LotterySystem {
	public LotterySystem() {
		super();
	}
	
public static void validateParticipant(ParticipantDTO participantDTO) throws LotteryBookingException{
		// WRITE YOUR CODE HERE
	}
	
	public static Boolean isValidAge(Integer age) {
		// WRITE YOUR CODE HERE
		
		return null;
		
	}
}
