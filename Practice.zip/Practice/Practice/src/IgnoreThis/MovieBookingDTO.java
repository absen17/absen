package ValidatorPracticeDTO;

public class MovieBookingDTO {

}
