package ValidatorPracticeDTO;

public class MovieBookingException extends Exception {

}
