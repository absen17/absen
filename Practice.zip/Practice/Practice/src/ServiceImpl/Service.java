package ServiceImpl;

public @interface Service {

	String value();

}
