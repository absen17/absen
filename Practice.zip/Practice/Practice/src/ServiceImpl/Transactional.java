package ServiceImpl;

public @interface Transactional {

}
