package ServiceImpl;

public class AthleteDTO {

	public final String getAthleteName = null;

	public static AthleteDTO prepareDTO(Athlete f) {
		// TODO Auto-generated method stub
		return null;
	}

	public String getAthleteName() {
		// TODO Auto-generated method stub
		return null;
	}

}
