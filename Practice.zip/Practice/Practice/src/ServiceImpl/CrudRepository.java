package ServiceImpl;

public interface CrudRepository<T1, T2> {

}
