package ServiceImpl;

import java.util.List;

public interface AthleteService {

	List<AthleteDTO> getListOfAthletes(String sport) throws AthleteRegistrationException;

}
