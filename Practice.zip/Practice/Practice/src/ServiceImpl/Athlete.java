package ServiceImpl;

public class Athlete {

}
