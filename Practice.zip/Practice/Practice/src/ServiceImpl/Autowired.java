package ServiceImpl;

public @interface Autowired {

}
