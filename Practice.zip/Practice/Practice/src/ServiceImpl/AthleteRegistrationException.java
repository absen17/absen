package ServiceImpl;

public class AthleteRegistrationException extends Exception {

	public AthleteRegistrationException(String string) {
		// TODO Auto-generated constructor stub
	}

}
