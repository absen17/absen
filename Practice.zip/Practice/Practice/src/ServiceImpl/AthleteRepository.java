package ServiceImpl;

import java.util.List;

public interface AthleteRepository extends CrudRepository<Athlete, Integer> { 
	
	//Your code here
	public List<Athlete> getAthletesBySport(String sport);
						//came from get api [copy & paste but read the question at first]
}
