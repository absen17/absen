package ServiceImplPractice; //Ignore on Your Machine

import java.util.ArrayList;
import java.util.List;

import ServiceImpl.Athlete;
import ServiceImpl.AthleteDTO;
import ServiceImpl.AthleteRegistrationException;
import ServiceImpl.AthleteRepository;
import ServiceImpl.AthleteService;
import ServiceImpl.Autowired;
import ServiceImpl.Service;
import ServiceImpl.Transactional;

@Service(value="athleteService")
@Transactional
public class AthleteServiceImpl implements AthleteService {
	@Autowired
	private AthleteRepository athleteRepository;
	
	@Override
	public List<AthleteDTO> getListOfAthletes(String sport) throws AthleteRegistrationException{
		//Your Code Here for GET
		
		return null;
	}
}
