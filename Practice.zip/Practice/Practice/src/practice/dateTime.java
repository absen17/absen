package practice;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class dateTime {
    public static void main(String[] args) {
//         Q1
//        LocalDate localDate= LocalDate.of(2012,12,31);
//        localDate = localDate.plus(2, ChronoUnit.MONTHS);
//        System.out.println(localDate);
        // ANS = 2013-02-28
        
        //Q2
//        LocalDate localDate = LocalDate.of(2020, 8, 12);
//        localDate = localDate.plusWeeks(4).minusMonths(1).plusYears(2);
//        System.out.println(localDate);
        //ANS = 2022-08-09
        
        
//    	=============
//    	LocalDate intakeYear = LocalDate.now();
//    	if(intakeYear.isBefore(intakeYear))
//    		return false;
//    	else
//    		return true;
//      =============
    	 LocalDate localDate= LocalDate.now().minusYears(0);
       System.out.println(localDate);
    	
    }
}