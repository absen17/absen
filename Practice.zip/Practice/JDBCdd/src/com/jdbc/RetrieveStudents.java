package com.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RetrieveStudents {
    public static void main(String[] args) {
        String selectSQL = "SELECT * FROM Student WHERE CourseName = ? AND Score > ?";

        try (Connection conn = DatabaseHelper.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(selectSQL)) {

            pstmt.setString(1, "JDBC");
            pstmt.setInt(2, 60);

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                String name = rs.getString("Name");
                int rollNumber = rs.getInt("RollNumber");
                String courseName = rs.getString("CourseName");
                int score = rs.getInt("Score");

                System.out.println("Name: " + name + ", RollNumber: " + rollNumber + ", CourseName: " + courseName + ", Score: " + score);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
