package com.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertStudents {
    public static void main(String[] args) {
        String insertSQL = "INSERT INTO Student (Name, RollNumber, CourseName, Score) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseHelper.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {

            conn.setAutoCommit(false);  // Start transaction

            pstmt.setString(1, "Alice");
            pstmt.setInt(2, 1);
            pstmt.setString(3, "JDBC");
            pstmt.setInt(4, 75);
            pstmt.addBatch();

            pstmt.setString(1, "Bob");
            pstmt.setInt(2, 2);
            pstmt.setString(3, "JDBC");
            pstmt.setInt(4, 65);
            pstmt.addBatch();

            pstmt.setString(1, "Charlie");
            pstmt.setInt(2, 3);
            pstmt.setString(3, "JDBC");
            pstmt.setInt(4, 55);
            pstmt.addBatch();

            pstmt.setString(1, "David");
            pstmt.setInt(2, 4);
            pstmt.setString(3, "JDBC");
            pstmt.setInt(4, 85);
            pstmt.addBatch();

            pstmt.setString(1, "Eve");
            pstmt.setInt(2, 5);
            pstmt.setString(3, "JDBC");
            pstmt.setInt(4, 45);
            pstmt.addBatch();

            pstmt.executeBatch();
            conn.commit();  // Commit transaction
            System.out.println("Records inserted successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

