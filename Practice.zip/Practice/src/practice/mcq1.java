package practice;

import java.util.HashMap;
import java.util.Map;

public class mcq1 {
	public static void main(String[] args) {
		Map<String, String> nameMap = new HashMap<String, String>();
		
		nameMap.put("A", "Andre");
		nameMap.put("B", "Bob");
		nameMap.put(null, null);
		nameMap.put("C", "Catlyn");
		nameMap.put(new String("A"),"Avan");
		System.out.println(nameMap);
	}

}
