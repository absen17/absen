package practice;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

class Trainee{
	int traineeId;
	String traineeName;
	Trainee(int cId, String name){
		this.traineeId= cId;
		this.traineeName=name;
	}
	//getters and setters
	// Getter method for traineeId
    public int getTraineeId() {
        return traineeId;
    }

    // Setter method for traineeId
    public void setTraineeId(int traineeId) {
        this.traineeId = traineeId;
    }

    // Getter method for traineeName
    public String getTraineeName() {
        return traineeName;
    }

    // Setter method for traineeName
    public void setTraineeName(String traineeName) {
        this.traineeName = traineeName;
    }
}

public class Tester {
	public static void main(String a[]) {
		List<Trainee> list = new ArrayList<Trainee>();
		Trainee c1 = new Trainee(110, "Patrick");
		Trainee c2 = new Trainee(112, "Chandler");
		Trainee c3 = new Trainee(113, "Darbie");
		Trainee c4 = new Trainee(115, "Kelly");
		list.add(c1);
		list.add(c2);
		list.add(c3);
		list.add(c4);
		if(list.contains(c3)) {
			list.set(1, list.get(3));
		}
		Stream<Trainee> stream = list.stream().filter(trainee -> trainee.getTraineeName().length()>5);
		stream.forEach((trainee) -> System.out.print(trainee.getTraineeId() + " "));
	}
}
